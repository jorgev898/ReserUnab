
import java.util.ArrayList;

// Clase Espacio
public class Espacio {
    private String nombre;
    private int capacidad;
    private ArrayList<String> recursos;
    private String tipoEspacio; // Nuevo atributo para el tipo de espacio

    public Espacio(String nombre, int capacidad, String tipoEspacio) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.recursos = new ArrayList<>();
        this.tipoEspacio = tipoEspacio;
    }

    // Getters y setters
}
