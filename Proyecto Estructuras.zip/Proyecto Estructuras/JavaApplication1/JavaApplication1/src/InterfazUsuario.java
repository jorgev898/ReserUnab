// Clase InterfazUsuario
public class InterfazUsuario {
    // Interfaz gráfica para que los usuarios interactúen con la aplicación
}
