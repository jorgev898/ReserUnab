import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Date;

public class AplicacionReservas {
    private BaseDatos baseDatos;
    private Usuario usuarioActual;
    private String tipoEspacioSeleccionado;
    private Date fechaInicio;
    private Date fechaFinalizacion;
    private ArrayList<String> recursosAdicionales;
    private static int ultimoIDReserva = 0;

    private int generarIDReserva() {
        ultimoIDReserva++;
        return ultimoIDReserva;
    }

    public AplicacionReservas(BaseDatos baseDatos) {
        this.baseDatos = baseDatos;
        this.usuarioActual = null;
    }

    private void mostrarNotificacion(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Notificación", JOptionPane.INFORMATION_MESSAGE);
    }

    // Métodos para el inicio de sesión y registro
    public boolean iniciarSesion(String ID, String contrasena) {
        // Lógica de inicio de sesión
        Usuario usuario = baseDatos.obtenerUsuario(ID);

        if (usuario != null && usuario.getContrasena().equals(contrasena)) {
            usuarioActual = usuario;
            return true; // Inicio de sesión exitoso
        } else {
            return false; // Inicio de sesión fallido
        }
    }

    public boolean registrarUsuario(String nombre, String ID, String contrasena) {
        // Lógica de registro de usuario
        if (baseDatos.existeUsuario(ID)) {
            return false; // El usuario ya existe, registro fallido
        }

        Usuario nuevoUsuario = new Usuario(nombre, ID, contrasena);
        baseDatos.guardarUsuario(nuevoUsuario);
        return true; // Registro exitoso
    }

    // Métodos para seleccionar el tipo de espacio, capturar información detallada
    // de la reserva y confirmar la reserva
    public void seleccionarTipoEspacio(String tipoEspacioSeleccionado) {
        // Lógica de selección del tipo de espacio
    }

    public void capturarNotas(String notas) {
        // Lógica para capturar notas
    }

    public void capturarFechas(Date fechaInicio, Date fechaFinalizacion) {
        // Lógica para capturar fechas
    }

    public void capturarRecursosAdicionales(ArrayList<String> recursosAdicionales) {
        // Lógica para capturar recursos adicionales
    }

    public boolean confirmarReserva() {
        // Lógica para confirmar la reserva

        // Validar los datos antes de confirmar la reserva
        boolean tipoEspacioValido = Validacion.validarTipoEspacio(tipoEspacioSeleccionado);

        if (tipoEspacioValido) {
            int nuevoID = generarIDReserva();
            // Crear una nueva instancia de Reserva y guardarla en la base de datos
            Reserva nuevaReserva = new Reserva(generarIDReserva(), usuarioActual, tipoEspacioSeleccionado,
                    fechaInicio, fechaFinalizacion, recursosAdicionales);

            baseDatos.guardarReserva(nuevaReserva);

            // Muestra una notificación o realiza otras acciones necesarias
            mostrarNotificacion("Tu reserva ha sido exitosa");

            // Restablece las variables después de la confirmación
            tipoEspacioSeleccionado = null;
            fechaInicio = null;
            fechaFinalizacion = null;
            recursosAdicionales = null;

            return true;
        } else {
            // Muestra un mensaje de error y no confirma la reserva
            mostrarNotificacion("Los datos ingresados no son válidos");
            return false;
        }
    }

    // Métodos para obtener y cancelar reservas
    public ArrayList<Reserva> obtenerReservasUsuario() {
        // Lógica para obtener reservas del usuario actual
        if (usuarioActual != null) {
            return baseDatos.obtenerReservasUsuario(usuarioActual);
        } else {
            return new ArrayList<>(); // Usuario no ha iniciado sesión, no hay reservas
        }
    }

    public boolean cancelarReserva(Reserva reserva) {
        // Lógica para cancelar la reserva
        return false;
    }
}
