import java.io.*;
import java.util.ArrayList;
import java.util.Date;

// Clase Usuario
public class Usuario {
    private String nombre;
    private String ID;
    private String contrasena; // Agregado para el inicio de sesión y registro

    public Usuario(String nombre, String ID, String contrasena) {
        this.nombre = nombre;
        this.ID = ID;
        this.contrasena = contrasena;
    }

    // Getters y setters

    // Otros métodos relacionados con el usuario
}
