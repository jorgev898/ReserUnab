import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class Proyecto extends JFrame {
    public Proyecto() {
        setTitle("Reservas de Espacios");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Configurar el fondo amarillo claro para el panel principal
        getContentPane().setBackground(new Color(255, 255, 204));

        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 255, 204)); // Establecer el fondo amarillo claro para el panel

        JLabel lblEspacio = new JLabel("Espacio:");
        JComboBox<String> comboBoxEspacio = new JComboBox<>();
        comboBoxEspacio.addItem("Aula D11");
        comboBoxEspacio.addItem("Aula D12");
        comboBoxEspacio.addItem("Aula D13");
        comboBoxEspacio.addItem("Aula D14");
        comboBoxEspacio.addItem("Aula D15");
        comboBoxEspacio.addItem("Aula D16");
        comboBoxEspacio.addItem("Aula D21");
        comboBoxEspacio.addItem("Aula D22");
        comboBoxEspacio.addItem("Aula D23");
        comboBoxEspacio.addItem("Aula D24");
        comboBoxEspacio.addItem("Aula D25");
        comboBoxEspacio.addItem("Aula D26");
        comboBoxEspacio.addItem("Aula D31");
        comboBoxEspacio.addItem("Aula D32");
        comboBoxEspacio.addItem("Aula D33");
        comboBoxEspacio.addItem("Aula D34");
        comboBoxEspacio.addItem("Aula D35");
        comboBoxEspacio.addItem("Aula D36");
        comboBoxEspacio.addItem("Aula L51");
        comboBoxEspacio.addItem("Aula L52");
        comboBoxEspacio.addItem("Aula L53");
        comboBoxEspacio.addItem("Aula H11");
        comboBoxEspacio.addItem("Aula H12");
        comboBoxEspacio.addItem("Aula H13");
        comboBoxEspacio.addItem("Aula H21");
        comboBoxEspacio.addItem("Aula H22");
        comboBoxEspacio.addItem("Aula H23");
        comboBoxEspacio.addItem("Aula K11");
        comboBoxEspacio.addItem("Aula K12");
        comboBoxEspacio.addItem("Aula K13");
        comboBoxEspacio.addItem("Aula K21");
        comboBoxEspacio.addItem("Aula K22");
        comboBoxEspacio.addItem("Aula K23");

        JLabel lblFecha = new JLabel("Fecha:");
        JTextField txtFecha = new JTextField(10);

        JLabel lblHoraInicio = new JLabel("Hora de inicio:");
        JComboBox<String> comboBoxHoraInicio = new JComboBox<>(generarHoras());
        
        JLabel lblHoraFin = new JLabel("Hora de fin:");
        JComboBox<String> comboBoxHoraFin = new JComboBox<>(generarHoras());

        JButton reservarButton = new JButton("Reservar");

        reservarButton.addActionListener((ActionEvent e) -> {
            String espacioSeleccionado = comboBoxEspacio.getSelectedItem().toString();
            String fecha = txtFecha.getText();
            String horaInicio = comboBoxHoraInicio.getSelectedItem().toString();
            String horaFin = comboBoxHoraFin.getSelectedItem().toString();

            // Construir el mensaje de confirmación personalizado.
            String mensaje = "<html><body style='background-color: orange; color: black;'>Espacio reservado con éxito<br>" +
                    "Aula: " + espacioSeleccionado + "<br>" +
                    "Fecha: " + fecha + "<br>" +
                    "Hora de inicio: " + horaInicio + "<br>" +
                    "Hora de fin: " + horaFin + "</body></html>";

            // Configurar las propiedades de estilo del JOptionPane
            UIManager.put("OptionPane.background", new Color(255, 200, 0)); // Fondo naranja

            // Mostrar el mensaje de confirmación.
            JOptionPane.showMessageDialog(null, mensaje);

            // Restaurar las propiedades de estilo a sus valores por defecto
            UIManager.put("OptionPane.background", UIManager.getColor("OptionPane.background"));
        });

        panel.add(lblEspacio);
        panel.add(comboBoxEspacio);
        panel.add(lblFecha);
        panel.add(txtFecha);
        panel.add(lblHoraInicio);
        panel.add(comboBoxHoraInicio);
        panel.add(lblHoraFin);
        panel.add(comboBoxHoraFin);
        panel.add(reservarButton);

        // Agregar componentes al panel
        add(panel);

        // Mostrar la ventana
        setVisible(true);
    }

    private String[] generarHoras() {
        List<String> horas = new ArrayList<>();
        for (int hora = 6; hora <= 24; hora++) {
            for (int minuto = 0; minuto < 60; minuto += 30) {
                String horaString = String.format("%02d:%02d", hora, minuto);
                horas.add(horaString);
            }
        }
        return horas.toArray(new String[0]);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Proyecto::new);
    }
}
