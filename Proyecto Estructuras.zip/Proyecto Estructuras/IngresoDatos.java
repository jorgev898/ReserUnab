import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;

public class IngresoDatos extends JFrame {

    private Map<String, Usuario> usuariosRegistrados = new HashMap<>();

    public IngresoDatos() {
        setTitle("Ingreso de Datos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un panel de pestañas para organizar "Iniciar Sesión" y "Registrarse"
        JTabbedPane tabbedPane = new JTabbedPane();

        // Panel para "Iniciar Sesión"
        JPanel iniciarSesionPanel = new JPanel();
        iniciarSesionPanel.setLayout(new GridLayout(0, 2)); // 0 filas, 2 columnas
        JTextField usuarioLoginField = new JTextField(20);
        JPasswordField contrasenaLoginField = new JPasswordField(20);
        JButton iniciarSesionButton = new JButton("Iniciar Sesión");
        iniciarSesionPanel.add(new JLabel("Usuario: "));
        iniciarSesionPanel.add(usuarioLoginField);
        iniciarSesionPanel.add(new JLabel("Contraseña: "));
        iniciarSesionPanel.add(contrasenaLoginField);
        iniciarSesionPanel.add(new JLabel()); // Espacio en blanco
        iniciarSesionPanel.add(iniciarSesionButton);
        iniciarSesionPanel.setBackground(new Color(173, 216, 230)); // Fondo azul claro

        // Panel para "Registrarse"
        JPanel registrarsePanel = new JPanel();
        registrarsePanel.setLayout(new GridLayout(0, 2)); // 0 filas, 2 columnas
        JTextField idRegistroField = new JTextField(10);
        JTextField nombreRegistroField = new JTextField(20);
        JTextField carreraRegistroField = new JTextField(20);
        JTextField semestreRegistroField = new JTextField(5);
        JTextField usuarioRegistroField = new JTextField(20);
        JPasswordField contrasenaRegistroField = new JPasswordField(20);
        JButton registrarseButton = new JButton("Registrarse");
        registrarsePanel.add(new JLabel("ID: "));
        registrarsePanel.add(idRegistroField);
        registrarsePanel.add(new JLabel("Nombre: "));
        registrarsePanel.add(nombreRegistroField);
        registrarsePanel.add(new JLabel("Carrera: "));
        registrarsePanel.add(carreraRegistroField);
        registrarsePanel.add(new JLabel("Semestre: "));
        registrarsePanel.add(semestreRegistroField);
        registrarsePanel.add(new JLabel("Usuario: "));
        registrarsePanel.add(usuarioRegistroField);
        registrarsePanel.add(new JLabel("Contraseña: "));
        registrarsePanel.add(contrasenaRegistroField);
        registrarsePanel.add(new JLabel()); // Espacio en blanco
        registrarsePanel.add(registrarseButton);
        registrarsePanel.setBackground(new Color(144, 238, 144)); // Fondo verde claro

        // Añadir paneles al panel de pestañas
        tabbedPane.addTab("Iniciar Sesión", iniciarSesionPanel);
        tabbedPane.addTab("Registrarse", registrarsePanel);

        // Agregar el panel de pestañas a la ventana
        getContentPane().add(tabbedPane);

        // Configurar el evento del botón "Iniciar Sesión"
        iniciarSesionButton.addActionListener((ActionEvent e) -> {
            String usuario = usuarioLoginField.getText();
            String contrasena = new String(contrasenaLoginField.getPassword());

            if (usuariosRegistrados.containsKey(usuario) && usuariosRegistrados.get(usuario).getContrasena().equals(contrasena)) {
                Usuario usuarioEncontrado = usuariosRegistrados.get(usuario);
                JOptionPane.showMessageDialog(null, "¡Bienvenido, " + usuarioEncontrado.getNombre() + "!");
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
            }
        });

        // Configurar el evento del botón "Registrarse"
        registrarseButton.addActionListener((ActionEvent e) -> {
            String id = idRegistroField.getText();
            String nombre = nombreRegistroField.getText();
            String carrera = carreraRegistroField.getText();
            String semestre = semestreRegistroField.getText();
            String usuario = usuarioRegistroField.getText();
            String contrasena = new String(contrasenaRegistroField.getPassword());

            // Verificar que todos los campos estén completos
            if (id.isEmpty() || nombre.isEmpty() || carrera.isEmpty() || semestre.isEmpty() || usuario.isEmpty() || contrasena.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Completa todos los campos para registrarte.");
            } else {
                // Aquí deberías guardar el usuario y la contraseña en tu base de datos
                // Por ahora, simplemente lo almacenaremos en el mapa en memoria
                Usuario nuevoUsuario = new Usuario(id, nombre, carrera, semestre, usuario, contrasena);
                usuariosRegistrados.put(usuario, nuevoUsuario);

                JOptionPane.showMessageDialog(null, "Registrarse:\nDatos guardados con éxito");
            }
        });

        // Ajustar el tamaño de la ventana y hacerla visible
        pack();
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(IngresoDatos::new);
    }

    // Clase auxiliar para representar un usuario
    private static class Usuario {
        private String id;
        private String nombre;
        private String carrera;
        private String semestre;
        private String usuario;
        private String contrasena;

        public Usuario(String id, String nombre, String carrera, String semestre,  String usuario, String contrasena) {
            this.id = id;
            this.nombre = nombre;
            this.carrera = carrera;
            this.semestre = semestre;
            this.usuario = usuario;
            this.contrasena = contrasena;
        }

        public String getContrasena() {
            return contrasena;
        }

        public String getNombre() {
            return nombre;
        }
    }
}
