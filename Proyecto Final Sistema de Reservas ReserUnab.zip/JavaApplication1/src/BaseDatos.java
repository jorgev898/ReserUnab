
// Clase BaseDatos
public class BaseDatos {
    // Métodos para guardar y obtener información de usuarios, espacios y reservas
}
