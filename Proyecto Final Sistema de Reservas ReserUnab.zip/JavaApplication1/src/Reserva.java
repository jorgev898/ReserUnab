
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;

// Clase Reserva
public class Reserva {
    private int IDReserva;
    private Usuario usuario;
    private Espacio espacio;
    private Date fechaInicio;
    private Date fechaFinalizacion;
    private ArrayList<String> recursosAdicionales;
    private String comentarios;
    private String estado;

    public Reserva(int IDReserva, Usuario usuario, Espacio espacio, Date fechaInicio, Date fechaFinalizacion) {
        this.IDReserva = IDReserva;
        this.usuario = usuario;
        this.espacio = espacio;
        this.fechaInicio = fechaInicio;
        this.fechaFinalizacion = fechaFinalizacion;
        this.recursosAdicionales = new ArrayList<>();
        this.comentarios = "";
        this.estado = "Pendiente";
    }

    // Getters y setters

    // Método para guardar una reserva en un archivo
    public void guardarReserva(String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(this);
            System.out.println("Reserva guardada exitosamente en " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método estático para cargar una reserva desde un archivo
    public static Reserva cargarReserva(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            Reserva reserva = (Reserva) ois.readObject();
            System.out.println("Reserva cargada exitosamente desde " + fileName);
            return reserva;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
