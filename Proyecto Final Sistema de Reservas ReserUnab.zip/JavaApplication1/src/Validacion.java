
import java.util.ArrayList;
import java.util.Date;

public class Validacion {
    public static boolean validarTipoEspacio(String tipoEspacio) {
        // Verifica si el tipo de espacio es uno de los valores permitidos (D1-1 o D2-2)
        return tipoEspacio != null && (tipoEspacio.equals("D1-1") || tipoEspacio.equals("D2-2"));
    }

    public static boolean validarFechas(Date fechaInicio, Date fechaFinalizacion) {
        // Lógica de validación para las fechas
        return true; // Devuelve true si son válidas, false si no lo son
    }

    public static boolean validarRecursosAdicionales(ArrayList<String> recursosAdicionales) {
        // Lógica de validación para los recursos adicionales
        return true; // Devuelve true si son válidos, false si no lo son
    }

    // Otros métodos de validación
}
